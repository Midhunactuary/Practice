package com.sf.htc.persistence.dao;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;

import com.sf.htc.persistence.model.Product;

public interface ProductDAO extends JpaRepository<Product,Integer>,JpaSpecificationExecutor<Product>{

}
