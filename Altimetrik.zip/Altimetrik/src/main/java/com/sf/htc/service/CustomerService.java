package com.sf.htc.service;

import com.sf.htc.persistence.dto.CustomerDTO;
import com.sf.htc.persistence.model.Customer;

public interface CustomerService {
	
	int addCustomer(CustomerDTO customerDTO);
	
	Customer checkExistingCustomer(String userName); 

}
