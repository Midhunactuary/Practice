package com.sf.htc.persistence.dto;

public class CustomerDTO {

}
