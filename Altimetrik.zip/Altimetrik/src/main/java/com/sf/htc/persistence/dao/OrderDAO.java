package com.sf.htc.persistence.dao;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;

import com.sf.htc.persistence.model.Order;

public interface OrderDAO extends JpaRepository<Order,Integer>,JpaSpecificationExecutor<Order> {

}
