package com.sf.htc;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AltimetrikApplication {

	public static void main(String[] args) {
		SpringApplication.run(AltimetrikApplication.class, args);
	}

}
