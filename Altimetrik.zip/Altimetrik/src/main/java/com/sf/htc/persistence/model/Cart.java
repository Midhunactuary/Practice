package com.sf.htc.persistence.model;

import java.io.Serializable;
import javax.persistence.*;

@Entity
@Table(name="cart")
public class Cart implements Serializable{	
	private static final long serialVersionUID = 1L;

	@OneToOne(fetch = FetchType.LAZY)
	@JoinColumn(name="customer_id")
	private int customerId;
	
	@OneToMany(fetch = FetchType.LAZY)
	@JoinColumn(name="product_id")
	private int productId;
	
	private int quantity;

	public int getCustomerId() {
		return customerId;
	}

	public void setCustomerId(int customerId) {
		this.customerId = customerId;
	}

	public int getProductId() {
		return productId;
	}

	public void setProductId(int productId) {
		this.productId = productId;
	}

	public int getQuantity() {
		return quantity;
	}

	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}

	public Cart() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Cart(int customerId, int productId, int quantity) {
		super();
		this.customerId = customerId;
		this.productId = productId;
		this.quantity = quantity;
	}
	
	
}
