package com.sf.htc.persistence.dao;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;

import com.sf.htc.persistence.model.Cart;

public interface CartDAO extends JpaRepository<Cart,Integer>,JpaSpecificationExecutor<Cart>{

}
