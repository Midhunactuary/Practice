package com.sf.htc.service.impl;

import org.springframework.stereotype.Service;

import com.sf.htc.persistence.dto.CustomerDTO;
import com.sf.htc.persistence.model.Customer;
import com.sf.htc.service.CustomerService;

@Service
public class CustomerServiceImpl implements CustomerService {

	@Override
	public int addCustomer(CustomerDTO customerDTO) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public Customer checkExistingCustomer(String userName) {
		// TODO Auto-generated method stub
		return null;
	}

}
